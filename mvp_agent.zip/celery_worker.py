from backend.tasks import celery
celery.worker_main(['worker', '--loglevel=info'])