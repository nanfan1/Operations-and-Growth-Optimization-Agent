# MVP 运营自动化骨架

1. 启动 Redis
2. 启动 Celery Worker: `python celery_worker.py`
3. 启动 FastAPI: `uvicorn backend.main:app --reload`
4. 打开 frontend/index.html 访问控制台