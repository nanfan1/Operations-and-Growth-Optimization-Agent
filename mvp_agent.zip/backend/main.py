from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import init_db
from .agents import dispatch_task
from celery import group
from .tasks import celery

app = FastAPI()
init_db()

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*']
)

@app.post('/run_task')
def run_task_endpoint(task_name: str, params: dict):
    task_group = group(dispatch_task(task_name, params))
    result = task_group.apply_async()
    return {'message': 'Task dispatched', 'task_ids': [t.id for t in result.results]}