from celery import Celery
from .database import get_connection
from .notification import notify

celery = Celery('tasks', broker='redis://localhost:6379/0')

@celery.task
def run_task(agent_name, params):
    result = f'{agent_name} processed {params}'
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO tasks (name, status, result) VALUES (?, ?, ?)', (agent_name, 'done', result))
    conn.commit()
    conn.close()
    notify(f'{agent_name} completed task')
    return result