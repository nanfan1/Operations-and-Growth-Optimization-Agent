def notify(message):
    print(f'[Notification placeholder] {message}')