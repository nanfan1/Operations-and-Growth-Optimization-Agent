from .tasks import run_task

AGENTS = ['DataCollector', 'StrategyGenerator', 'ReportGenerator']

def dispatch_task(task_name, params):
    if task_name == 'run_campaign_analysis':
        return [run_task.s(agent, params) for agent in AGENTS]
    return []